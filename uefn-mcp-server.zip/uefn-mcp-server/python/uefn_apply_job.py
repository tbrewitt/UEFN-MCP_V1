# UEFN MCP bridge script.
# Runs inside Unreal Editor for Fortnite / Unreal Editor embedded Python via -ExecutePythonScript.
# It reads a JSON job from --uefn-mcp-job=PATH and writes a JSON result to job.resultPath.

import json
import math
import os
import sys
import traceback

try:
    import unreal  # type: ignore
except Exception as exc:  # pragma: no cover - only exists inside Unreal
    unreal = None


def _arg_value(prefix):
    for arg in sys.argv:
        if arg.startswith(prefix):
            return arg[len(prefix):]
    return None


def _write_result(path, ok, message, data=None, errors=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"ok": ok, "message": message, "data": data or {}, "errors": errors or []}, f, indent=2)


def _vector(t):
    return unreal.Vector(float(t.get("x", 0)), float(t.get("y", 0)), float(t.get("z", 0)))


def _rotator(t):
    return unreal.Rotator(float(t.get("pitch", 0)), float(t.get("yaw", 0)), float(t.get("roll", 0)))


def _editor_actor_subsystem():
    if hasattr(unreal, "EditorActorSubsystem"):
        return unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    return None


def _spawn_actor(asset, transform):
    subsystem = _editor_actor_subsystem()
    location = _vector(transform)
    rotation = _rotator(transform)
    if subsystem and hasattr(subsystem, "spawn_actor_from_object"):
        return subsystem.spawn_actor_from_object(asset, location, rotation)
    if hasattr(unreal, "EditorLevelLibrary") and hasattr(unreal.EditorLevelLibrary, "spawn_actor_from_object"):
        return unreal.EditorLevelLibrary.spawn_actor_from_object(asset, location, rotation)
    raise RuntimeError("No supported spawn_actor_from_object API found in this UEFN Python environment.")


def _all_level_actors():
    subsystem = _editor_actor_subsystem()
    if subsystem and hasattr(subsystem, "get_all_level_actors"):
        return list(subsystem.get_all_level_actors())
    if hasattr(unreal, "EditorLevelLibrary"):
        return list(unreal.EditorLevelLibrary.get_all_level_actors())
    return []


def _actor_label(actor):
    if hasattr(actor, "get_actor_label"):
        return actor.get_actor_label()
    return actor.get_name()


def _find_by_label(label):
    return [a for a in _all_level_actors() if _actor_label(a) == label or _actor_label(a).startswith(label)]


def _set_label(actor, label):
    if hasattr(actor, "set_actor_label"):
        actor.set_actor_label(label)


def _set_tags(actor, tags):
    if tags is None:
        return
    try:
        actor.tags = [unreal.Name(str(t)) for t in tags]
    except Exception:
        pass


def _set_scale(actor, scale):
    if scale is None:
        return
    try:
        actor.set_actor_scale3d(unreal.Vector(float(scale), float(scale), float(scale)))
    except Exception:
        pass


def place_assets(payload):
    placed = []
    errors = []
    for item in payload.get("items", []):
        asset_path = item.get("assetPath")
        if not asset_path:
            errors.append({"code": "ASSET_PATH_REQUIRED", "message": "Missing assetPath", "item": item})
            continue
        asset = unreal.load_asset(asset_path)
        if asset is None:
            errors.append({"code": "ASSET_LOAD_FAILED", "message": "Could not load asset", "assetPath": asset_path})
            continue
        for index, transform in enumerate(item.get("transforms", [])):
            try:
                actor = _spawn_actor(asset, transform)
                if actor is None:
                    raise RuntimeError("spawn_actor_from_object returned None")
                label = item.get("label") or item.get("id") or "mcp_actor"
                final_label = f"{label}_{index + 1:03d}" if len(item.get("transforms", [])) > 1 else label
                _set_label(actor, final_label)
                _set_tags(actor, item.get("tags", []))
                _set_scale(actor, transform.get("scale", item.get("scale")))
                placed.append({"label": final_label, "assetPath": asset_path, "location": transform})
            except Exception as exc:
                errors.append({"code": "SPAWN_FAILED", "message": str(exc), "assetPath": asset_path, "transform": transform})
    _save_dirty()
    return {"placed": placed, "errors": errors}


def edit_actors(payload):
    operation = payload.get("operation")
    label = payload.get("label")
    actors = _find_by_label(label)
    changed = []
    subsystem = _editor_actor_subsystem()
    for actor in actors:
        if operation == "delete":
            if subsystem and hasattr(subsystem, "destroy_actor"):
                subsystem.destroy_actor(actor)
            elif hasattr(unreal, "EditorLevelLibrary"):
                unreal.EditorLevelLibrary.destroy_actor(actor)
            changed.append({"label": _actor_label(actor), "operation": "delete"})
        elif operation == "move":
            t = payload.get("transform", {})
            actor.set_actor_location(_vector(t), False, False)
            actor.set_actor_rotation(_rotator(t), False)
            _set_scale(actor, t.get("scale"))
            changed.append({"label": _actor_label(actor), "operation": "move", "transform": t})
        elif operation == "rename":
            new_label = payload.get("newLabel")
            _set_label(actor, new_label)
            changed.append({"label": new_label, "operation": "rename"})
        else:
            raise RuntimeError(f"Unsupported edit operation: {operation}")
    _save_dirty()
    return {"matched": len(actors), "changed": changed}


def connect_devices(payload):
    # Generic allow-listed property setter. UEFN may reject non-UI / non-allow-listed properties.
    connections = payload.get("connections", [])
    results = []
    errors = []
    for c in connections:
        source_label = c.get("sourceLabel")
        target_label = c.get("targetLabel")
        property_name = c.get("propertyName")
        sources = _find_by_label(source_label)
        targets = _find_by_label(target_label)
        if not sources or not targets:
            errors.append({"code": "ACTOR_NOT_FOUND", "message": "Source or target actor not found", "connection": c})
            continue
        for source in sources:
            try:
                value = targets if c.get("asArray", False) else targets[0]
                source.set_editor_property(property_name, value)
                results.append({"sourceLabel": _actor_label(source), "propertyName": property_name, "targetLabels": [_actor_label(t) for t in targets]})
            except Exception as exc:
                errors.append({"code": "PROPERTY_SET_FAILED", "message": str(exc), "connection": c})
    _save_dirty()
    return {"connections": results, "errors": errors}


def scan_assets(payload):
    root_paths = payload.get("rootPaths") or ["/Game"]
    query = (payload.get("query") or "").lower()
    max_results = int(payload.get("maxResults") or 500)
    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    found = []
    for root in root_paths:
        assets = registry.get_assets_by_path(root, recursive=True)
        for data in assets:
            object_path = str(data.get_soft_object_path())
            name = str(data.asset_name)
            asset_class = str(data.asset_class_path.asset_name) if hasattr(data, "asset_class_path") else str(data.asset_class)
            haystack = f"{object_path} {name} {asset_class}".lower()
            if query and query not in haystack:
                continue
            found.append({"id": name, "assetPath": object_path, "displayName": name, "assetClass": asset_class})
            if len(found) >= max_results:
                return {"assets": found, "truncated": True}
    return {"assets": found, "truncated": False}


def validate(payload):
    labels = {}
    duplicates = []
    for actor in _all_level_actors():
        label = _actor_label(actor)
        labels[label] = labels.get(label, 0) + 1
    for label, count in labels.items():
        if count > 1:
            duplicates.append({"label": label, "count": count})
    return {"actorCount": len(labels), "duplicateLabels": duplicates}


def _save_dirty():
    if hasattr(unreal, "EditorLoadingAndSavingUtils"):
        unreal.EditorLoadingAndSavingUtils.save_dirty_packages(True, True)
    elif hasattr(unreal, "EditorAssetLibrary"):
        unreal.EditorAssetLibrary.save_loaded_assets([])


def save(payload):
    _save_dirty()
    return {"saved": True}


def run_python(payload):
    # Optional power-user escape hatch; the MCP server should keep allowUnsafePython=false unless the caller explicitly needs it.
    code = payload.get("code")
    if not code:
        raise RuntimeError("code is required")
    scope = {"unreal": unreal, "math": math}
    exec(code, scope, scope)
    return {"executed": True}


def main():
    job_path = _arg_value("--uefn-mcp-job=") or os.environ.get("UEFN_MCP_JOB")
    if not job_path:
        raise RuntimeError("Missing --uefn-mcp-job=PATH")
    with open(job_path, "r", encoding="utf-8") as f:
        job = json.load(f)
    result_path = job["resultPath"]
    if unreal is None:
        _write_result(result_path, False, "This script must run inside UEFN/Unreal embedded Python.", errors=[{"code": "UNREAL_MODULE_NOT_AVAILABLE"}])
        return
    actions = {
        "place_assets": place_assets,
        "edit_actors": edit_actors,
        "connect_devices": connect_devices,
        "scan_assets": scan_assets,
        "validate": validate,
        "save": save,
        "run_python": run_python,
    }
    action = job.get("action")
    if action not in actions:
        raise RuntimeError(f"Unsupported action: {action}")
    data = actions[action](job.get("payload", {}))
    _write_result(result_path, True, f"UEFN job '{action}' completed.", data=data)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        result_path = None
        try:
            job_path = _arg_value("--uefn-mcp-job=") or os.environ.get("UEFN_MCP_JOB")
            if job_path:
                with open(job_path, "r", encoding="utf-8") as f:
                    result_path = json.load(f).get("resultPath")
        except Exception:
            pass
        tb = traceback.format_exc()
        if result_path:
            _write_result(result_path, False, str(exc), errors=[{"code": "BRIDGE_EXCEPTION", "message": str(exc), "traceback": tb}])
        else:
            raise
