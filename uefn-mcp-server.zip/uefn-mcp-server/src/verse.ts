import path from 'node:path';
import fs from 'fs-extra';
import { currentProject } from './project.js';
import { UserFacingError } from './errors.js';

export type VerseTemplate = 'loadout_on_spawn' | 'trigger_barrier_toggle' | 'round_announcement' | 'custom';

function sanitizeVerseName(name: string): string {
  const cleaned = name.replace(/[^a-zA-Z0-9_]/g, '_');
  if (!/^[A-Za-z_]/.test(cleaned)) return `v_${cleaned}`;
  return cleaned;
}

export function verseTemplate(template: VerseTemplate, className: string, customCode?: string): string {
  const c = sanitizeVerseName(className);
  if (template === 'custom') {
    if (!customCode?.trim()) throw new UserFacingError('CUSTOM_VERSE_REQUIRED', 'customCode is required when template=custom.');
    return customCode.trimEnd() + '\n';
  }
  if (template === 'loadout_on_spawn') {
    return `using { /Fortnite.com/Devices }\nusing { /Verse.org/Simulation }\n\n# Grants the configured Item Granter to every player when they spawn.\n# In UEFN, assign Spawners and Granter in the Details panel or through an allow-listed editor property workflow.\n${c} := class(creative_device):\n\n    @editable\n    Spawners : []player_spawner_device = array{}\n\n    @editable\n    Granter : item_granter_device = item_granter_device{}\n\n    OnBegin<override>()<suspends>:void =\n        for (Spawner : Spawners):\n            Spawner.SpawnedEvent.Subscribe(GrantLoadout)\n\n    GrantLoadout(Agent : agent):void =\n        Granter.GrantItem(Agent)\n`;
  }
  if (template === 'trigger_barrier_toggle') {
    return `using { /Fortnite.com/Devices }\nusing { /Verse.org/Simulation }\n\n# Toggles barriers whenever the configured trigger fires.\n${c} := class(creative_device):\n\n    @editable\n    Trigger : trigger_device = trigger_device{}\n\n    @editable\n    Barriers : []barrier_device = array{}\n\n    OnBegin<override>()<suspends>:void =\n        Trigger.TriggeredEvent.Subscribe(OnTriggered)\n\n    OnTriggered(MaybeAgent : ?agent):void =\n        for (Barrier : Barriers):\n            Barrier.Disable()\n`;
  }
  return `using { /Fortnite.com/Devices }\nusing { /Verse.org/Simulation }\nusing { /UnrealEngine.com/Temporary/Diagnostics }\n\n${c} := class(creative_device):\n\n    @editable\n    Message : string = "Round started"\n\n    OnBegin<override>()<suspends>:void =\n        Print(Message)\n`;
}

export async function verseRoot(): Promise<string> {
  const project = await currentProject();
  const candidates = [
    path.join(project.projectRoot, 'Verse'),
    path.join(project.projectRoot, 'Content'),
    path.join(project.projectRoot, 'Plugins', project.projectName, 'Content'),
  ];
  for (const candidate of candidates) {
    if (await fs.pathExists(candidate)) return candidate;
  }
  await fs.ensureDir(candidates[0]);
  return candidates[0];
}

export async function writeVerseFile(fileName: string, code: string): Promise<string> {
  const root = await verseRoot();
  const safe = sanitizeVerseName(fileName.replace(/\.verse$/i, '')) + '.verse';
  const filePath = path.join(root, safe);
  await fs.ensureDir(path.dirname(filePath));
  await fs.writeFile(filePath, code, 'utf8');
  return filePath;
}

export async function editVerseFile(fileName: string, operation: 'replace_all' | 'append' | 'replace_text', content?: string, search?: string, replacement?: string): Promise<string> {
  const root = await verseRoot();
  const filePath = path.join(root, fileName.endsWith('.verse') ? fileName : `${fileName}.verse`);
  if (!(await fs.pathExists(filePath))) throw new UserFacingError('VERSE_FILE_NOT_FOUND', `Verse file not found: ${filePath}`);
  const before = await fs.readFile(filePath, 'utf8');
  let after = before;
  if (operation === 'replace_all') {
    if (content === undefined) throw new UserFacingError('CONTENT_REQUIRED', 'content is required for replace_all.');
    after = content;
  } else if (operation === 'append') {
    if (content === undefined) throw new UserFacingError('CONTENT_REQUIRED', 'content is required for append.');
    after = before.trimEnd() + '\n' + content.trimEnd() + '\n';
  } else {
    if (!search) throw new UserFacingError('SEARCH_REQUIRED', 'search is required for replace_text.');
    if (replacement === undefined) throw new UserFacingError('REPLACEMENT_REQUIRED', 'replacement is required for replace_text.');
    if (!before.includes(search)) throw new UserFacingError('SEARCH_NOT_FOUND', `Text not found in ${fileName}.`);
    after = before.replace(search, replacement);
  }
  await fs.writeFile(filePath, after, 'utf8');
  return filePath;
}
