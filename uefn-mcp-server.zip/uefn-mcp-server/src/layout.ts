import type { Transform } from './types.js';

export type PlacementPattern = 'explicit' | 'circle' | 'grid' | 'line' | 'around_spawn';

export interface PlacementRequest {
  count: number;
  pattern: PlacementPattern;
  origin: Transform;
  radius?: number;
  spacing?: number;
  positions?: Transform[];
}

export function generateTransforms(req: PlacementRequest): Transform[] {
  const count = Math.max(1, Math.floor(req.count));
  const origin = req.origin;
  if (req.pattern === 'explicit') {
    if (!req.positions || req.positions.length === 0) return [origin];
    return req.positions.slice(0, count).map((p) => ({ ...origin, ...p }));
  }
  if (req.pattern === 'circle' || req.pattern === 'around_spawn') {
    const radius = req.radius ?? 1200;
    return Array.from({ length: count }, (_, i) => {
      const angle = (Math.PI * 2 * i) / count;
      const yaw = (angle * 180) / Math.PI + 90;
      return {
        x: origin.x + Math.cos(angle) * radius,
        y: origin.y + Math.sin(angle) * radius,
        z: origin.z,
        pitch: origin.pitch ?? 0,
        yaw,
        roll: origin.roll ?? 0,
        scale: origin.scale,
      };
    });
  }
  if (req.pattern === 'line') {
    const spacing = req.spacing ?? 400;
    const start = -((count - 1) * spacing) / 2;
    return Array.from({ length: count }, (_, i) => ({ ...origin, x: origin.x + start + i * spacing }));
  }
  const spacing = req.spacing ?? 500;
  const cols = Math.ceil(Math.sqrt(count));
  const rows = Math.ceil(count / cols);
  const startX = -((cols - 1) * spacing) / 2;
  const startY = -((rows - 1) * spacing) / 2;
  return Array.from({ length: count }, (_, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    return { ...origin, x: origin.x + startX + col * spacing, y: origin.y + startY + row * spacing };
  });
}
