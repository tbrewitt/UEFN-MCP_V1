import fs from 'fs-extra';
import path from 'node:path';
import type { AssetCatalog, ProjectState, UefnMcpConfig } from './types.js';
import { readCatalog } from './assets.js';

export interface ValidationIssue {
  severity: 'error' | 'warning' | 'info';
  code: string;
  message: string;
  details?: unknown;
}

export async function validateLocal(config: UefnMcpConfig, project: ProjectState): Promise<ValidationIssue[]> {
  const issues: ValidationIssue[] = [];
  if (!(await fs.pathExists(project.projectRoot))) {
    issues.push({ severity: 'error', code: 'PROJECT_ROOT_MISSING', message: `Project root missing: ${project.projectRoot}` });
  }
  if (!(await fs.pathExists(project.projectFile))) {
    issues.push({ severity: 'error', code: 'PROJECT_FILE_MISSING', message: `Project file missing: ${project.projectFile}` });
  }
  if (!config.dryRun && !config.uefnEditorExe) {
    issues.push({ severity: 'error', code: 'UEFN_EDITOR_NOT_CONFIGURED', message: 'dryRun=false requires uefnEditorExe.' });
  }
  if (config.uefnEditorExe && !(await fs.pathExists(config.uefnEditorExe))) {
    issues.push({ severity: 'error', code: 'UEFN_EDITOR_NOT_FOUND', message: `UEFN executable not found: ${config.uefnEditorExe}` });
  }
  const catalog: AssetCatalog = await readCatalog(config);
  const duplicateIds = catalog.entries.map((e) => e.id).filter((id, i, arr) => arr.indexOf(id) !== i);
  if (duplicateIds.length) issues.push({ severity: 'error', code: 'DUPLICATE_ASSET_IDS', message: 'Asset catalog contains duplicate IDs.', details: duplicateIds });
  if (!catalog.entries.length) issues.push({ severity: 'warning', code: 'EMPTY_ASSET_CATALOG', message: 'Asset catalog is empty. Run scan_project_assets or add assets manually before placing props/devices.' });
  const verseDirs = [path.join(project.projectRoot, 'Verse'), path.join(project.projectRoot, 'Content'), path.join(project.projectRoot, 'Plugins', project.projectName, 'Content')];
  const hasVerseDir = await Promise.any(verseDirs.map(async (dir) => ((await fs.pathExists(dir)) ? dir : Promise.reject()))).catch(() => undefined);
  if (!hasVerseDir) issues.push({ severity: 'info', code: 'VERSE_DIR_NOT_FOUND', message: 'No common Verse directory found yet; generate_verse_script will create ./Verse.' });
  return issues;
}
