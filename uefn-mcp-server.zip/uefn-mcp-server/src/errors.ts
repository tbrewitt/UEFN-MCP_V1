export class UserFacingError extends Error {
  public readonly code: string;
  public readonly details?: unknown;

  constructor(code: string, message: string, details?: unknown) {
    super(message);
    this.name = 'UserFacingError';
    this.code = code;
    this.details = details;
  }
}

export function toUserFacingError(error: unknown): UserFacingError {
  if (error instanceof UserFacingError) return error;
  if (error instanceof Error) return new UserFacingError('INTERNAL_ERROR', error.message, { stack: error.stack });
  return new UserFacingError('INTERNAL_ERROR', String(error));
}
