export type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };

export type PythonMode = 'commandline';

export interface UefnMcpConfig {
  projectsRoot: string;
  templateProjectPath?: string;
  uefnEditorExe?: string;
  pythonMode: PythonMode;
  dryRun: boolean;
  assetCatalogPath?: string;
  defaultMapName?: string;
  maxCommandSeconds: number;
}

export interface ProjectState {
  projectRoot: string;
  projectFile: string;
  projectName: string;
  openedAt: string;
}

export type AssetKind =
  | 'prop'
  | 'device'
  | 'terrain'
  | 'building'
  | 'spawn_point'
  | 'weapon'
  | 'item_granter'
  | 'barrier'
  | 'trigger'
  | 'environment';

export interface AssetCatalogEntry {
  id: string;
  kind: AssetKind;
  assetPath: string;
  displayName?: string;
  notes?: string;
  tags?: string[];
}

export interface AssetCatalog {
  version: 1;
  generatedAt?: string;
  entries: AssetCatalogEntry[];
}

export interface Transform {
  x: number;
  y: number;
  z: number;
  pitch?: number;
  yaw?: number;
  roll?: number;
  scale?: number;
}

export interface UefnJob {
  jobId: string;
  action:
    | 'place_assets'
    | 'edit_actors'
    | 'connect_devices'
    | 'scan_assets'
    | 'validate'
    | 'save'
    | 'run_python';
  projectRoot: string;
  payload: Record<string, unknown>;
  resultPath: string;
}

export interface ToolResponsePayload {
  ok: boolean;
  message: string;
  data?: JsonValue;
  errors?: Array<{ code: string; message: string; details?: JsonValue }>;
}
