import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'fs-extra';

export function mcpHome(): string {
  return process.env.UEFN_MCP_HOME || path.join(os.homedir(), '.uefn-mcp');
}

export function configPath(): string {
  return path.join(mcpHome(), 'config.json');
}

export function statePath(): string {
  return path.join(mcpHome(), 'state.json');
}

export function packagedBridgePath(): string {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'python', 'uefn_apply_job.py');
}

export async function ensureHome(): Promise<void> {
  await fs.ensureDir(mcpHome());
  await fs.ensureDir(path.join(mcpHome(), 'jobs'));
  await fs.ensureDir(path.join(mcpHome(), 'logs'));
}

export function normalizeAbs(p: string): string {
  return path.resolve(p).replace(/\\/g, '/');
}
