import path from 'node:path';
import fs from 'fs-extra';
import { z } from 'zod';
import { configPath, ensureHome, mcpHome, normalizeAbs } from './paths.js';
import type { UefnMcpConfig } from './types.js';
import { UserFacingError } from './errors.js';

const ConfigSchema = z.object({
  projectsRoot: z.string().min(1),
  templateProjectPath: z.string().optional(),
  uefnEditorExe: z.string().optional(),
  pythonMode: z.literal('commandline').default('commandline'),
  dryRun: z.boolean().default(false),
  assetCatalogPath: z.string().optional(),
  defaultMapName: z.string().optional(),
  maxCommandSeconds: z.number().int().positive().default(900),
});

export async function readConfig(): Promise<UefnMcpConfig> {
  await ensureHome();
  const p = configPath();
  if (!(await fs.pathExists(p))) {
    const defaultConfig: UefnMcpConfig = {
      projectsRoot: normalizeAbs(path.join(mcpHome(), 'projects')),
      pythonMode: 'commandline',
      dryRun: true,
      maxCommandSeconds: 900,
    };
    await fs.writeJson(p, defaultConfig, { spaces: 2 });
    return defaultConfig;
  }
  const raw = await fs.readJson(p);
  const parsed = ConfigSchema.parse(raw);
  return {
    ...parsed,
    projectsRoot: normalizeAbs(parsed.projectsRoot),
    templateProjectPath: parsed.templateProjectPath ? normalizeAbs(parsed.templateProjectPath) : undefined,
    uefnEditorExe: parsed.uefnEditorExe ? normalizeAbs(parsed.uefnEditorExe) : undefined,
    assetCatalogPath: parsed.assetCatalogPath ? normalizeAbs(parsed.assetCatalogPath) : undefined,
  };
}

export async function writeConfig(next: Partial<UefnMcpConfig>): Promise<UefnMcpConfig> {
  const existing = await readConfig();
  const merged = ConfigSchema.parse({ ...existing, ...next });
  const normalized: UefnMcpConfig = {
    ...merged,
    projectsRoot: normalizeAbs(merged.projectsRoot),
    templateProjectPath: merged.templateProjectPath ? normalizeAbs(merged.templateProjectPath) : undefined,
    uefnEditorExe: merged.uefnEditorExe ? normalizeAbs(merged.uefnEditorExe) : undefined,
    assetCatalogPath: merged.assetCatalogPath ? normalizeAbs(merged.assetCatalogPath) : undefined,
  };
  await fs.ensureDir(normalized.projectsRoot);
  await fs.writeJson(configPath(), normalized, { spaces: 2 });
  return normalized;
}

export function requireEditor(config: UefnMcpConfig): string {
  if (!config.uefnEditorExe) {
    throw new UserFacingError(
      'UEFN_EDITOR_NOT_CONFIGURED',
      'UEFN editor executable is not configured. Call configure_uefn_mcp with uefnEditorExe, or keep dryRun=true for planning-only jobs.'
    );
  }
  return config.uefnEditorExe;
}
