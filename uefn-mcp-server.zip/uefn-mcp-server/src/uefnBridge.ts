import path from 'node:path';
import fs from 'fs-extra';
import { execa } from 'execa';
import { randomUUID } from 'node:crypto';
import type { ProjectState, UefnJob, UefnMcpConfig } from './types.js';
import { requireEditor } from './config.js';
import { packagedBridgePath, normalizeAbs } from './paths.js';
import { ensureProjectMcpDirs } from './project.js';
import { UserFacingError } from './errors.js';

export interface BridgeResult {
  dryRun: boolean;
  jobPath: string;
  resultPath: string;
  stdout?: string;
  stderr?: string;
  result?: unknown;
}

export async function runUefnJob(config: UefnMcpConfig, project: ProjectState, action: UefnJob['action'], payload: Record<string, unknown>): Promise<BridgeResult> {
  const { jobsDir } = await ensureProjectMcpDirs(project.projectRoot);
  const jobId = randomUUID();
  const jobPath = path.join(jobsDir, `${jobId}.job.json`);
  const resultPath = path.join(jobsDir, `${jobId}.result.json`);
  const job: UefnJob = { jobId, action, projectRoot: project.projectRoot, payload, resultPath: normalizeAbs(resultPath) };
  await fs.writeJson(jobPath, job, { spaces: 2 });

  if (config.dryRun) {
    return { dryRun: true, jobPath: normalizeAbs(jobPath), resultPath: normalizeAbs(resultPath) };
  }

  const editorExe = requireEditor(config);
  const bridgePath = packagedBridgePath();
  if (!(await fs.pathExists(bridgePath))) {
    throw new UserFacingError('BRIDGE_SCRIPT_NOT_FOUND', `Bridge script not found: ${bridgePath}`);
  }

  const args = [project.projectFile, `-ExecutePythonScript=${bridgePath}`, `--uefn-mcp-job=${jobPath}`, '-Log', '-StdOut', '-allowStdOutLogVerbosity'];
  let result;
  try {
    result = await execa(editorExe, args, {
      timeout: config.maxCommandSeconds * 1000,
      all: true,
      reject: false,
      windowsHide: false,
    });
  } catch (error) {
    throw new UserFacingError('UEFN_PROCESS_FAILED', 'Failed to launch UEFN Python bridge.', { error: String(error), editorExe, args });
  }

  if (!(await fs.pathExists(resultPath))) {
    throw new UserFacingError('UEFN_RESULT_NOT_FOUND', 'UEFN job did not write a result file.', {
      exitCode: result.exitCode,
      all: result.all?.slice(-4000),
      jobPath: normalizeAbs(jobPath),
      resultPath: normalizeAbs(resultPath),
    });
  }

  const jobResult = await fs.readJson(resultPath);
  if (result.exitCode !== 0 || jobResult?.ok === false) {
    throw new UserFacingError('UEFN_JOB_FAILED', jobResult?.message || 'UEFN job failed.', {
      exitCode: result.exitCode,
      output: result.all?.slice(-4000),
      jobResult,
      jobPath: normalizeAbs(jobPath),
    });
  }

  return {
    dryRun: false,
    jobPath: normalizeAbs(jobPath),
    resultPath: normalizeAbs(resultPath),
    stdout: result.stdout,
    stderr: result.stderr,
    result: jobResult,
  };
}
