import type { ToolResponsePayload } from './types.js';
import { toUserFacingError } from './errors.js';

export function ok(message: string, data?: ToolResponsePayload['data']) {
  const payload: ToolResponsePayload = { ok: true, message, data };
  return {
    content: [{ type: 'text' as const, text: JSON.stringify(payload, null, 2) }],
  };
}

export function fail(error: unknown) {
  const e = toUserFacingError(error);
  const payload: ToolResponsePayload = {
    ok: false,
    message: e.message,
    errors: [{ code: e.code, message: e.message, details: e.details as ToolResponsePayload['data'] }],
  };
  return {
    isError: true,
    content: [{ type: 'text' as const, text: JSON.stringify(payload, null, 2) }],
  };
}

export async function tool(fn: () => Promise<ReturnType<typeof ok>> | ReturnType<typeof ok>) {
  try {
    return await fn();
  } catch (error) {
    return fail(error);
  }
}
