#!/usr/bin/env node
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import fs from 'fs-extra';

import { readConfig, writeConfig } from './config.js';
import { ok, tool } from './response.js';
import { createProjectFromTemplate, currentProject, openProject } from './project.js';
import { readCatalog, upsertCatalogEntries, writeCatalog, requireAsset } from './assets.js';
import { generateTransforms } from './layout.js';
import { runUefnJob } from './uefnBridge.js';
import { editVerseFile, verseTemplate, writeVerseFile } from './verse.js';
import { validateLocal } from './validators.js';
import type { AssetCatalogEntry, AssetKind, Transform } from './types.js';
import { UserFacingError } from './errors.js';

const server = new McpServer({
  name: 'uefn-mcp-server',
  version: '1.0.0',
});

const TransformSchema = z.object({
  x: z.number().describe('Unreal X position in centimeters'),
  y: z.number().describe('Unreal Y position in centimeters'),
  z: z.number().describe('Unreal Z position in centimeters'),
  pitch: z.number().optional(),
  yaw: z.number().optional(),
  roll: z.number().optional(),
  scale: z.number().positive().optional(),
});

const AssetKindSchema = z.enum(['prop', 'device', 'terrain', 'building', 'spawn_point', 'weapon', 'item_granter', 'barrier', 'trigger', 'environment']);

function registerTool(
  name: string,
  description: string,
  inputSchema: z.ZodRawShape,
  handler: (args: any) => Promise<ReturnType<typeof ok>>
) {
  server.tool(name, description, inputSchema, async (args: any) => tool(() => handler(args)));
}

registerTool(
  'configure_uefn_mcp',
  'Configure local paths and safety settings. Set dryRun=false only after uefnEditorExe and a real UEFN template project are configured.',
  {
    projectsRoot: z.string().optional(),
    templateProjectPath: z.string().optional(),
    uefnEditorExe: z.string().optional(),
    dryRun: z.boolean().optional(),
    assetCatalogPath: z.string().optional(),
    maxCommandSeconds: z.number().int().positive().optional(),
  },
  async (args) => {
    const config = await writeConfig(args);
    return ok('UEFN MCP configuration saved.', config as never);
  }
);

registerTool(
  'get_uefn_mcp_status',
  'Return server configuration, current project, and asset catalog stats.',
  {},
  async () => {
    const config = await readConfig();
    let project = null;
    try { project = await currentProject(); } catch { project = null; }
    const catalog = await readCatalog(config);
    return ok('UEFN MCP status loaded.', { config, currentProject: project, assetCount: catalog.entries.length } as never);
  }
);

registerTool(
  'create_island_project',
  'Create a new UEFN island project by copying a real blank/template UEFN project directory. This avoids fabricating undocumented Epic project manifests.',
  {
    projectName: z.string().min(1),
    targetRoot: z.string().optional(),
  },
  async ({ projectName, targetRoot }) => {
    const config = await readConfig();
    const project = await createProjectFromTemplate(config, projectName, targetRoot);
    return ok('Created and opened UEFN island project from template.', project as never);
  }
);

registerTool(
  'open_island_project',
  'Open an existing UEFN project folder for subsequent MCP operations.',
  {
    projectRoot: z.string().min(1),
  },
  async ({ projectRoot }) => {
    const project = await openProject(projectRoot);
    return ok('Opened UEFN island project.', project as never);
  }
);

registerTool(
  'add_asset_to_catalog',
  'Add or update a known UEFN asset path. The server only places assets from this catalog or explicit /Game paths.',
  {
    id: z.string().min(1),
    kind: AssetKindSchema,
    assetPath: z.string().min(1),
    displayName: z.string().optional(),
    notes: z.string().optional(),
    tags: z.array(z.string()).optional(),
  },
  async (entry) => {
    const config = await readConfig();
    const catalog = await upsertCatalogEntries(config, [entry as AssetCatalogEntry]);
    return ok('Asset added to catalog.', { assetCount: catalog.entries.length, entry } as never);
  }
);

registerTool(
  'list_known_assets',
  'List assets currently available to the MCP server, optionally filtered by kind or text query.',
  {
    kind: AssetKindSchema.optional(),
    query: z.string().optional(),
    limit: z.number().int().positive().max(500).optional(),
  },
  async ({ kind, query, limit }) => {
    const config = await readConfig();
    const catalog = await readCatalog(config);
    const q = query?.toLowerCase();
    const entries = catalog.entries
      .filter((e) => !kind || e.kind === kind)
      .filter((e) => !q || `${e.id} ${e.assetPath} ${e.displayName ?? ''} ${(e.tags ?? []).join(' ')}`.toLowerCase().includes(q))
      .slice(0, limit ?? 100);
    return ok('Known assets listed.', { entries, total: catalog.entries.length } as never);
  }
);

registerTool(
  'scan_project_assets',
  'Ask UEFN to scan project asset registry and optionally write matching assets into the MCP asset catalog. Requires dryRun=false.',
  {
    query: z.string().optional(),
    rootPaths: z.array(z.string()).optional(),
    maxResults: z.number().int().positive().max(5000).optional(),
    kindForImportedEntries: AssetKindSchema.optional(),
    writeToCatalog: z.boolean().default(false),
  },
  async ({ query, rootPaths, maxResults, kindForImportedEntries, writeToCatalog }) => {
    const config = await readConfig();
    const project = await currentProject();
    const bridge = await runUefnJob(config, project, 'scan_assets', { query, rootPaths, maxResults });
    let imported = 0;
    if (!bridge.dryRun && writeToCatalog) {
      const assets = (bridge.result as any)?.data?.assets ?? [];
      const entries: AssetCatalogEntry[] = assets.map((a: any) => ({
        id: a.id,
        kind: kindForImportedEntries ?? inferKind(a.assetPath, a.assetClass),
        assetPath: a.assetPath,
        displayName: a.displayName,
        tags: [String(a.assetClass ?? 'asset')],
      }));
      await upsertCatalogEntries(config, entries);
      imported = entries.length;
    }
    return ok('Project asset scan job completed.', { bridge, imported } as never);
  }
);

registerTool(
  'place_assets',
  'Place props, devices, buildings, terrain meshes, barriers, triggers, environment assets, or configured device assets into the active UEFN level.',
  {
    items: z.array(z.object({
      assetId: z.string().min(1).describe('Catalog id or explicit /Game asset path'),
      kind: AssetKindSchema.optional(),
      label: z.string().optional(),
      count: z.number().int().positive().max(1000).default(1),
      pattern: z.enum(['explicit', 'circle', 'grid', 'line', 'around_spawn']).default('explicit'),
      origin: TransformSchema.default({ x: 0, y: 0, z: 0 }),
      radius: z.number().positive().optional(),
      spacing: z.number().positive().optional(),
      positions: z.array(TransformSchema).optional(),
      tags: z.array(z.string()).optional(),
      scale: z.number().positive().optional(),
    })).min(1),
  },
  async ({ items }) => {
    const config = await readConfig();
    const project = await currentProject();
    const resolved = [];
    for (const item of items) {
      const asset = await requireAsset(config, item.assetId, item.kind as AssetKind | undefined);
      const transforms = generateTransforms({
        count: item.count,
        pattern: item.pattern,
        origin: item.origin as Transform,
        radius: item.radius,
        spacing: item.spacing,
        positions: item.positions as Transform[] | undefined,
      }).map((t) => ({ ...t, scale: t.scale ?? item.scale }));
      resolved.push({
        id: asset.id,
        assetPath: asset.assetPath,
        kind: asset.kind,
        label: item.label ?? asset.id.replace(/[^a-zA-Z0-9_]/g, '_'),
        transforms,
        tags: item.tags ?? [asset.kind, 'mcp'],
        scale: item.scale,
      });
    }
    const bridge = await runUefnJob(config, project, 'place_assets', { items: resolved });
    return ok('Place assets job completed.', { bridge, requestedItems: resolved.length } as never);
  }
);

registerTool(
  'edit_actors',
  'Move, rename, or delete level actors by exact label or label prefix.',
  {
    label: z.string().min(1),
    operation: z.enum(['move', 'rename', 'delete']),
    transform: TransformSchema.optional(),
    newLabel: z.string().optional(),
  },
  async ({ label, operation, transform, newLabel }) => {
    if (operation === 'move' && !transform) throw new UserFacingError('TRANSFORM_REQUIRED', 'transform is required for move.');
    if (operation === 'rename' && !newLabel) throw new UserFacingError('NEW_LABEL_REQUIRED', 'newLabel is required for rename.');
    const config = await readConfig();
    const project = await currentProject();
    const bridge = await runUefnJob(config, project, 'edit_actors', { label, operation, transform, newLabel });
    return ok('Edit actors job completed.', bridge as never);
  }
);

registerTool(
  'connect_devices',
  'Connect UEFN devices or Verse devices by setting allow-listed editor properties. If UEFN rejects a property, the tool returns a structured PROPERTY_SET_FAILED error.',
  {
    connections: z.array(z.object({
      sourceLabel: z.string().min(1),
      targetLabel: z.string().min(1),
      propertyName: z.string().min(1),
      asArray: z.boolean().optional(),
    })).min(1),
  },
  async ({ connections }) => {
    const config = await readConfig();
    const project = await currentProject();
    const bridge = await runUefnJob(config, project, 'connect_devices', { connections });
    return ok('Connect devices job completed.', bridge as never);
  }
);

registerTool(
  'generate_verse_script',
  'Generate a Verse script file for common Fortnite island logic, such as loadout on spawn or trigger-driven barrier logic.',
  {
    fileName: z.string().min(1),
    className: z.string().min(1),
    template: z.enum(['loadout_on_spawn', 'trigger_barrier_toggle', 'round_announcement', 'custom']),
    customCode: z.string().optional(),
  },
  async ({ fileName, className, template, customCode }) => {
    const code = verseTemplate(template, className, customCode);
    const filePath = await writeVerseFile(fileName, code);
    return ok('Verse script generated. Build Verse in UEFN after generation.', { filePath, template } as never);
  }
);

registerTool(
  'edit_verse_script',
  'Edit an existing Verse file by replacing all content, appending code, or replacing a text span.',
  {
    fileName: z.string().min(1),
    operation: z.enum(['replace_all', 'append', 'replace_text']),
    content: z.string().optional(),
    search: z.string().optional(),
    replacement: z.string().optional(),
  },
  async ({ fileName, operation, content, search, replacement }) => {
    const filePath = await editVerseFile(fileName, operation, content, search, replacement);
    return ok('Verse script edited.', { filePath } as never);
  }
);

registerTool(
  'create_1v1_arena',
  'High-level helper that places a flat floor, barriers, two spawn points, and optional item granters/item spawners from catalog asset IDs.',
  {
    arenaCenter: TransformSchema.default({ x: 0, y: 0, z: 0 }),
    size: z.number().positive().default(4096),
    floorAssetId: z.string().min(1),
    barrierAssetId: z.string().min(1),
    playerSpawnerAssetId: z.string().min(1),
    itemDeviceAssetId: z.string().optional(),
  },
  async ({ arenaCenter, size, floorAssetId, barrierAssetId, playerSpawnerAssetId, itemDeviceAssetId }) => {
    const half = size / 2;
    const items: any[] = [
      { assetId: floorAssetId, kind: 'terrain', label: 'mcp_1v1_floor', count: 1, pattern: 'explicit', origin: arenaCenter, scale: size / 1000, tags: ['mcp', 'arena', 'floor'] },
      { assetId: barrierAssetId, kind: 'barrier', label: 'mcp_1v1_barrier_north', count: 1, pattern: 'explicit', origin: { ...arenaCenter, y: arenaCenter.y + half }, tags: ['mcp', 'arena', 'barrier'] },
      { assetId: barrierAssetId, kind: 'barrier', label: 'mcp_1v1_barrier_south', count: 1, pattern: 'explicit', origin: { ...arenaCenter, y: arenaCenter.y - half }, tags: ['mcp', 'arena', 'barrier'] },
      { assetId: barrierAssetId, kind: 'barrier', label: 'mcp_1v1_barrier_east', count: 1, pattern: 'explicit', origin: { ...arenaCenter, x: arenaCenter.x + half, yaw: 90 }, tags: ['mcp', 'arena', 'barrier'] },
      { assetId: barrierAssetId, kind: 'barrier', label: 'mcp_1v1_barrier_west', count: 1, pattern: 'explicit', origin: { ...arenaCenter, x: arenaCenter.x - half, yaw: 90 }, tags: ['mcp', 'arena', 'barrier'] },
      { assetId: playerSpawnerAssetId, kind: 'spawn_point', label: 'mcp_1v1_spawn_a', count: 1, pattern: 'explicit', origin: { ...arenaCenter, x: arenaCenter.x - half / 2, z: arenaCenter.z + 10, yaw: 0 }, tags: ['mcp', 'arena', 'spawn'] },
      { assetId: playerSpawnerAssetId, kind: 'spawn_point', label: 'mcp_1v1_spawn_b', count: 1, pattern: 'explicit', origin: { ...arenaCenter, x: arenaCenter.x + half / 2, z: arenaCenter.z + 10, yaw: 180 }, tags: ['mcp', 'arena', 'spawn'] },
    ];
    if (itemDeviceAssetId) {
      items.push({ assetId: itemDeviceAssetId, label: 'mcp_1v1_item_device_a', count: 1, pattern: 'explicit', origin: { ...arenaCenter, x: arenaCenter.x - 600, z: arenaCenter.z + 25 }, tags: ['mcp', 'arena', 'item'] });
      items.push({ assetId: itemDeviceAssetId, label: 'mcp_1v1_item_device_b', count: 1, pattern: 'explicit', origin: { ...arenaCenter, x: arenaCenter.x + 600, z: arenaCenter.z + 25 }, tags: ['mcp', 'arena', 'item'] });
    }
    const config = await readConfig();
    const project = await currentProject();
    const resolved = [];
    for (const item of items) {
      const asset = await requireAsset(config, item.assetId, item.kind as AssetKind | undefined);
      const transforms = generateTransforms({ count: item.count, pattern: item.pattern, origin: item.origin as Transform });
      resolved.push({ id: asset.id, assetPath: asset.assetPath, kind: asset.kind, label: item.label, transforms, tags: item.tags, scale: item.scale });
    }
    const bridge = await runUefnJob(config, project, 'place_assets', { items: resolved });
    return ok('1v1 arena placement job completed.', { bridge, actorsRequested: resolved.length } as never);
  }
);

registerTool(
  'validate_island',
  'Validate local project configuration and optionally ask UEFN to inspect the open level for basic actor issues.',
  {
    includeUefnLevelCheck: z.boolean().default(true),
  },
  async ({ includeUefnLevelCheck }) => {
    const config = await readConfig();
    const project = await currentProject();
    const localIssues = await validateLocal(config, project);
    let bridge = null;
    if (includeUefnLevelCheck) {
      bridge = await runUefnJob(config, project, 'validate', {});
    }
    return ok('Island validation completed.', { localIssues, bridge } as never);
  }
);

registerTool(
  'save_project_changes',
  'Save dirty UEFN packages and project changes through the UEFN Python bridge.',
  {},
  async () => {
    const config = await readConfig();
    const project = await currentProject();
    const bridge = await runUefnJob(config, project, 'save', {});
    return ok('Project save job completed.', bridge as never);
  }
);

registerTool(
  'run_uefn_python',
  'Advanced escape hatch for trusted local users only: run raw Python inside UEFN. Disabled unless allowUnsafePython=true.',
  {
    code: z.string().min(1),
    allowUnsafePython: z.boolean().default(false),
  },
  async ({ code, allowUnsafePython }) => {
    if (!allowUnsafePython) throw new UserFacingError('UNSAFE_PYTHON_DISABLED', 'Set allowUnsafePython=true only for trusted local code.');
    const config = await readConfig();
    const project = await currentProject();
    const bridge = await runUefnJob(config, project, 'run_python', { code });
    return ok('Raw UEFN Python executed.', bridge as never);
  }
);

registerTool(
  'write_example_ai_commands',
  'Write documentation with example AI commands for the configured project.',
  {},
  async () => {
    const project = await currentProject();
    const docPath = `${project.projectRoot}/.uefn-mcp/docs/example-ai-commands.md`;
    const content = `# Example AI commands for UEFN MCP\n\n- place 10 trees around spawn\n- give every player a pump shotgun on spawn\n- create a 1v1 arena with barriers and item spawners\n- add two triggers that open the north barrier\n- validate the island and tell me what is broken\n- generate a Verse device that grants loadout on spawn\n\n## How agents should translate commands\n\n### place 10 trees around spawn\nCall \`place_assets\` with an asset catalog id like \`tree.oak\`, \`count=10\`, \`pattern=around_spawn\`, and an origin around the spawn area.\n\n### give every player a pump shotgun on spawn\nCall \`generate_verse_script\` with template \`loadout_on_spawn\`, then place or configure a Player Spawner and Item Granter in UEFN. The Item Granter must contain the pump shotgun item in its device settings. If those properties are allow-listed in your UEFN version, call \`connect_devices\` to wire the Verse device editables.\n\n### create a 1v1 arena\nCall \`create_1v1_arena\` with configured catalog IDs for floor, barrier, player spawner, and item device assets.\n`;
    await fs.ensureDir(`${project.projectRoot}/.uefn-mcp/docs`);
    await fs.writeFile(docPath, content, 'utf8');
    return ok('Example AI commands documentation written.', { docPath } as never);
  }
);

function inferKind(assetPath: string, assetClass?: string): AssetKind {
  const text = `${assetPath} ${assetClass ?? ''}`.toLowerCase();
  if (text.includes('barrier')) return 'barrier';
  if (text.includes('trigger')) return 'trigger';
  if (text.includes('spawner') || text.includes('spawn')) return 'spawn_point';
  if (text.includes('granter')) return 'item_granter';
  if (text.includes('device')) return 'device';
  if (text.includes('floor') || text.includes('terrain') || text.includes('landscape')) return 'terrain';
  if (text.includes('wall') || text.includes('building')) return 'building';
  if (text.includes('tree') || text.includes('rock') || text.includes('foliage')) return 'environment';
  return 'prop';
}

const transport = new StdioServerTransport();
await server.connect(transport);
