import fs from 'fs-extra';
import path from 'node:path';
import { z } from 'zod';
import type { AssetCatalog, AssetCatalogEntry, AssetKind, UefnMcpConfig } from './types.js';
import { currentProject } from './project.js';
import { UserFacingError } from './errors.js';

const EntrySchema = z.object({
  id: z.string().min(1),
  kind: z.enum(['prop', 'device', 'terrain', 'building', 'spawn_point', 'weapon', 'item_granter', 'barrier', 'trigger', 'environment']),
  assetPath: z.string().min(1),
  displayName: z.string().optional(),
  notes: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

const CatalogSchema = z.object({
  version: z.literal(1),
  generatedAt: z.string().optional(),
  entries: z.array(EntrySchema),
});

export async function defaultCatalogPath(config: UefnMcpConfig): Promise<string> {
  if (config.assetCatalogPath) return config.assetCatalogPath;
  try {
    const project = await currentProject();
    return path.join(project.projectRoot, '.uefn-mcp', 'assets.catalog.json');
  } catch {
    return path.join(config.projectsRoot, 'assets.catalog.json');
  }
}

export async function readCatalog(config: UefnMcpConfig): Promise<AssetCatalog> {
  const p = await defaultCatalogPath(config);
  if (!(await fs.pathExists(p))) {
    return { version: 1, generatedAt: new Date().toISOString(), entries: [] };
  }
  return CatalogSchema.parse(await fs.readJson(p));
}

export async function writeCatalog(config: UefnMcpConfig, catalog: AssetCatalog): Promise<string> {
  const p = await defaultCatalogPath(config);
  await fs.ensureDir(path.dirname(p));
  const parsed = CatalogSchema.parse(catalog);
  await fs.writeJson(p, parsed, { spaces: 2 });
  return p;
}

export async function upsertCatalogEntries(config: UefnMcpConfig, entries: AssetCatalogEntry[]): Promise<AssetCatalog> {
  const catalog = await readCatalog(config);
  const map = new Map(catalog.entries.map((entry) => [entry.id, entry]));
  for (const entry of entries) map.set(entry.id, EntrySchema.parse(entry));
  const next: AssetCatalog = { version: 1, generatedAt: new Date().toISOString(), entries: [...map.values()].sort((a, b) => a.id.localeCompare(b.id)) };
  await writeCatalog(config, next);
  return next;
}

export async function requireAsset(config: UefnMcpConfig, idOrPath: string, expectedKind?: AssetKind): Promise<AssetCatalogEntry> {
  if (idOrPath.startsWith('/')) {
    return { id: idOrPath, kind: expectedKind ?? 'prop', assetPath: idOrPath };
  }
  const catalog = await readCatalog(config);
  const entry = catalog.entries.find((candidate) => candidate.id === idOrPath);
  if (!entry) {
    throw new UserFacingError(
      'ASSET_NOT_IN_CATALOG',
      `Asset '${idOrPath}' is not in the catalog. Run scan_project_assets or add it with add_asset_to_catalog.`,
      { idOrPath, catalogEntries: catalog.entries.length }
    );
  }
  if (expectedKind && entry.kind !== expectedKind) {
    throw new UserFacingError('ASSET_KIND_MISMATCH', `Asset '${idOrPath}' is '${entry.kind}', expected '${expectedKind}'.`);
  }
  return entry;
}
