import path from 'node:path';
import fs from 'fs-extra';
import fg from 'fast-glob';
import type { ProjectState, UefnMcpConfig } from './types.js';
import { statePath, normalizeAbs } from './paths.js';
import { UserFacingError } from './errors.js';

export async function findProjectFile(projectRoot: string): Promise<string> {
  const files = await fg(['*.uefnproject', '*.uproject'], { cwd: projectRoot, absolute: true, onlyFiles: true, deep: 1 });
  if (!files.length) {
    throw new UserFacingError('PROJECT_FILE_NOT_FOUND', `No .uefnproject or .uproject found in ${projectRoot}`);
  }
  return normalizeAbs(files[0]);
}

export async function openProject(projectRoot: string): Promise<ProjectState> {
  const root = normalizeAbs(projectRoot);
  if (!(await fs.pathExists(root))) throw new UserFacingError('PROJECT_ROOT_NOT_FOUND', `Project root does not exist: ${root}`);
  const projectFile = await findProjectFile(root);
  const projectName = path.basename(projectFile).replace(/\.(uefnproject|uproject)$/i, '');
  const state: ProjectState = { projectRoot: root, projectFile, projectName, openedAt: new Date().toISOString() };
  await fs.writeJson(statePath(), state, { spaces: 2 });
  return state;
}

export async function currentProject(): Promise<ProjectState> {
  if (!(await fs.pathExists(statePath()))) {
    throw new UserFacingError('NO_PROJECT_OPEN', 'No UEFN project is open. Call open_island_project first.');
  }
  const state = (await fs.readJson(statePath())) as ProjectState;
  if (!(await fs.pathExists(state.projectRoot))) {
    throw new UserFacingError('PROJECT_ROOT_NOT_FOUND', `Current project root no longer exists: ${state.projectRoot}`);
  }
  if (!(await fs.pathExists(state.projectFile))) {
    throw new UserFacingError('PROJECT_FILE_NOT_FOUND', `Current project file no longer exists: ${state.projectFile}`);
  }
  return state;
}

export async function createProjectFromTemplate(config: UefnMcpConfig, projectName: string, targetRoot?: string): Promise<ProjectState> {
  if (!config.templateProjectPath) {
    throw new UserFacingError(
      'TEMPLATE_REQUIRED',
      'Creating a real UEFN island requires a real UEFN template project. Configure templateProjectPath with a blank UEFN project you created once in UEFN.'
    );
  }
  if (!(await fs.pathExists(config.templateProjectPath))) {
    throw new UserFacingError('TEMPLATE_NOT_FOUND', `Template project path does not exist: ${config.templateProjectPath}`);
  }
  const safeName = projectName.replace(/[^a-zA-Z0-9_-]/g, '_');
  const root = normalizeAbs(targetRoot ? path.join(targetRoot, safeName) : path.join(config.projectsRoot, safeName));
  if (await fs.pathExists(root)) throw new UserFacingError('PROJECT_ALREADY_EXISTS', `Project already exists: ${root}`);
  await fs.copy(config.templateProjectPath, root, {
    filter: (src) => !src.includes('/Saved/') && !src.includes('\\Saved\\') && !src.includes('/Intermediate/') && !src.includes('\\Intermediate\\'),
  });
  await fs.ensureDir(path.join(root, '.uefn-mcp'));
  await fs.writeJson(path.join(root, '.uefn-mcp', 'project.json'), { projectName, createdAt: new Date().toISOString(), templateProjectPath: config.templateProjectPath }, { spaces: 2 });
  return openProject(root);
}

export async function ensureProjectMcpDirs(projectRoot: string): Promise<{ jobsDir: string; verseDir: string; docsDir: string }> {
  const jobsDir = path.join(projectRoot, '.uefn-mcp', 'jobs');
  const verseDir = path.join(projectRoot, 'Verse');
  const docsDir = path.join(projectRoot, '.uefn-mcp', 'docs');
  await fs.ensureDir(jobsDir);
  await fs.ensureDir(verseDir);
  await fs.ensureDir(docsDir);
  return { jobsDir, verseDir, docsDir };
}
