import { describe, expect, it } from 'vitest';
import { generateTransforms } from '../src/layout.js';

describe('generateTransforms', () => {
  it('creates circle positions', () => {
    const positions = generateTransforms({ count: 4, pattern: 'circle', origin: { x: 0, y: 0, z: 0 }, radius: 100 });
    expect(positions).toHaveLength(4);
    expect(Math.round(positions[0].x)).toBe(100);
    expect(Math.round(positions[1].y)).toBe(100);
  });

  it('creates grid positions', () => {
    const positions = generateTransforms({ count: 4, pattern: 'grid', origin: { x: 0, y: 0, z: 0 }, spacing: 100 });
    expect(positions).toHaveLength(4);
    expect(positions[0].x).toBe(-50);
  });
});
