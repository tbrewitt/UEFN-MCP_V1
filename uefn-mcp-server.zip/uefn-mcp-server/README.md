# UEFN MCP Server

A production-minded Model Context Protocol server that lets an AI agent operate Unreal Editor for Fortnite (UEFN) through structured tools.

This repo is intentionally honest about the real UEFN boundary: it does **not** invent hidden Fortnite APIs. It uses the supported MCP pattern plus UEFN/Unreal Python automation and Verse file generation. Epic documents UEFN Python as an early-preview workflow for automated scene setup and even mentions remote execution for MCP-style agentic AI integrations. Because UEFN validation can reject non-allow-listed edits, every tool returns structured success/error JSON instead of pretending every device property is always writable.

## What it can do

- Create a new island project by copying a real blank/template UEFN project.
- Open an existing UEFN project.
- Scan project assets through the UEFN asset registry.
- Maintain an asset catalog with stable AI-friendly IDs like `tree.oak` or `device.item_granter`.
- Place configured props, devices, terrain meshes, buildings, spawn points, barriers, triggers, and environment assets.
- Generate and edit Verse scripts.
- Attempt logical device connections through UEFN Python property setting, with clear errors when UEFN rejects a property.
- Validate local setup and run a basic level actor check through UEFN.
- Save dirty packages automatically after bridge jobs.
- Write example AI command documentation.

## Requirements

- Windows with UEFN installed.
- Node.js 20+.
- A real blank/template UEFN project created once through the UEFN UI.
- Python Editor Scripting enabled in the UEFN project settings.
- For actual editing, `dryRun=false` and a valid UEFN/Unreal editor executable path.

## Install

```bash
npm install
npm run build
```

For development:

```bash
npm run dev
```

## Configure

First run in safe dry-run mode:

```json
{
  "projectsRoot": "D:/UEFNProjects",
  "templateProjectPath": "D:/UEFNTemplates/BlankVerseIsland",
  "uefnEditorExe": "C:/Path/To/Your/UEFN-Or-UnrealEditor-Executable.exe",
  "dryRun": true,
  "maxCommandSeconds": 900
}
```

Then call the MCP tool:

```json
{
  "tool": "configure_uefn_mcp",
  "arguments": {
    "projectsRoot": "D:/UEFNProjects",
    "templateProjectPath": "D:/UEFNTemplates/BlankVerseIsland",
    "uefnEditorExe": "C:/Path/To/Your/UEFN-Or-UnrealEditor-Executable.exe",
    "dryRun": false
  }
}
```

The exact UEFN executable path can vary by installation. The server keeps it configurable instead of hardcoding a path.

## Connect to an MCP client

Example Claude Desktop style config:

```json
{
  "mcpServers": {
    "uefn": {
      "command": "node",
      "args": ["D:/path/to/uefn-mcp-server/dist/src/index.js"]
    }
  }
}
```

Or during development:

```json
{
  "mcpServers": {
    "uefn": {
      "command": "npx",
      "args": ["tsx", "D:/path/to/uefn-mcp-server/src/index.ts"]
    }
  }
}
```

## Typical setup flow

1. Create a blank UEFN project manually once. This becomes your template.
2. Enable Python Editor Scripting in that project.
3. Start the MCP server.
4. Call `configure_uefn_mcp`.
5. Call `create_island_project` or `open_island_project`.
6. Call `scan_project_assets` with `writeToCatalog=true`, or add known assets manually with `add_asset_to_catalog`.
7. Use tools like `place_assets`, `generate_verse_script`, `connect_devices`, `validate_island`, and `save_project_changes`.

## Important UEFN reality check

UEFN can automate scene setup through Python, but Epic warns that modifications outside the allow-listed UI surface may fail validation. This is why the server:

- uses a template project rather than fabricating `.uefnproject` files,
- places only real Content Browser assets from a catalog or explicit `/Game/...` paths,
- attempts device wiring only through exposed editor properties,
- returns structured `PROPERTY_SET_FAILED`, `ASSET_LOAD_FAILED`, or validation errors instead of silently pretending success.

## Tool list

- `configure_uefn_mcp`
- `get_uefn_mcp_status`
- `create_island_project`
- `open_island_project`
- `scan_project_assets`
- `add_asset_to_catalog`
- `list_known_assets`
- `place_assets`
- `edit_actors`
- `connect_devices`
- `generate_verse_script`
- `edit_verse_script`
- `create_1v1_arena`
- `validate_island`
- `save_project_changes`
- `run_uefn_python`
- `write_example_ai_commands`

## Example AI commands and tool translations

### “place 10 trees around spawn”

Tool call:

```json
{
  "tool": "place_assets",
  "arguments": {
    "items": [
      {
        "assetId": "tree.oak",
        "kind": "environment",
        "label": "spawn_tree",
        "count": 10,
        "pattern": "around_spawn",
        "origin": { "x": 0, "y": 0, "z": 0 },
        "radius": 1400,
        "scale": 1.0
      }
    ]
  }
}
```

### “give every player a pump shotgun on spawn”

Tool call 1:

```json
{
  "tool": "generate_verse_script",
  "arguments": {
    "fileName": "loadout_on_spawn",
    "className": "loadout_on_spawn",
    "template": "loadout_on_spawn"
  }
}
```

Then place/configure a Player Spawner and Item Granter. Put the pump shotgun into the Item Granter device settings in UEFN. If your UEFN build exposes the editable fields to Python, connect them with `connect_devices`; otherwise the generated Verse device still gives you the correct editable workflow in UEFN.

### “create a 1v1 arena with barriers and item spawners”

```json
{
  "tool": "create_1v1_arena",
  "arguments": {
    "arenaCenter": { "x": 0, "y": 0, "z": 0 },
    "size": 4096,
    "floorAssetId": "arena.floor",
    "barrierAssetId": "device.barrier",
    "playerSpawnerAssetId": "device.player_spawner",
    "itemDeviceAssetId": "device.item_granter"
  }
}
```

## Notes on Verse files

UEFN normally manages Verse files through Verse Explorer. This server writes `.verse` files into the first detected common Verse/content folder, preferring:

1. `<project>/Verse`
2. `<project>/Content`
3. `<project>/Plugins/<ProjectName>/Content`

After generation, build Verse in UEFN so the device class appears in the Content Browser.

## Security

`run_uefn_python` is disabled unless `allowUnsafePython=true` is passed in the tool call. Keep it disabled for normal agent workflows.

## Troubleshooting

- `TEMPLATE_REQUIRED`: Create a blank UEFN project manually and configure `templateProjectPath`.
- `ASSET_NOT_IN_CATALOG`: Run `scan_project_assets` or call `add_asset_to_catalog`.
- `UEFN_RESULT_NOT_FOUND`: UEFN launched but did not run/write the bridge result. Check the UEFN log and executable path.
- `PROPERTY_SET_FAILED`: UEFN rejected the device property. Wire that field in the Details panel or adjust to an allow-listed property.
