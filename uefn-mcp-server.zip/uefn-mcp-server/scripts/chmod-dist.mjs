import { chmodSync, existsSync } from 'node:fs';
if (existsSync('dist/src/index.js')) chmodSync('dist/src/index.js', 0o755);
if (existsSync('dist/index.js')) chmodSync('dist/index.js', 0o755);
