# Tool Contract

All tools return JSON text with this shape:

```json
{
  "ok": true,
  "message": "Human readable summary",
  "data": {}
}
```

Errors return:

```json
{
  "ok": false,
  "message": "Human readable error",
  "errors": [
    { "code": "ERROR_CODE", "message": "Detailed message", "details": {} }
  ]
}
```

## Asset placement contract

The MCP server does not guess Fortnite device paths. It places assets from:

- `assets.catalog.json`, or
- explicit `/Game/...` object paths supplied by a trusted user/agent.

This is required because UEFN project asset paths depend on imported content, templates, and Fortnite device exposure.

## Device connection contract

`connect_devices` sets editor properties on source actors:

```json
{
  "sourceLabel": "my_verse_device",
  "targetLabel": "my_spawner",
  "propertyName": "Spawners",
  "asArray": true
}
```

UEFN can reject properties that are not exposed or not allow-listed. That is a real validation boundary, not an MCP server bug.
