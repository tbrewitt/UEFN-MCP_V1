# Example natural-language commands for an AI agent

## Build commands

- Create a blank island called `Titus1v1`.
- Open my existing UEFN project at `D:/UEFNProjects/Titus1v1`.
- Scan all project assets containing `tree` and save them to the catalog as environment assets.
- Place 10 trees around spawn with 1400 cm radius.
- Create a 1v1 arena with barriers and item spawners.
- Generate a Verse device that grants loadout on spawn.
- Connect the loadout Verse device to both player spawners and the item granter.
- Validate the island and explain any errors.
- Save all project changes.

## Good AI behavior

- Always call `validate_island` after major changes.
- Prefer catalog IDs over raw asset paths.
- Never assume an Item Granter contains a weapon; it must be configured in UEFN or through an exposed allow-listed property.
- When UEFN rejects a property, report the exact `PROPERTY_SET_FAILED` error and suggest the manual Details-panel field.
